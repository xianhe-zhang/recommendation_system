class Context:
    def __init__(self, user_id: int = None, anime_id: int = None) -> None:
        self.user_id = user_id
        self.anime_id = anime_id
